
create table customer(
	cust_id int PRIMARY KEY,
    c_fname varchar(15),
    c_lname varchar(15),
    c_mnum bigint,
    c_adrs varchar(30),
    bkd_pro varchar(40)		);
select * from customer;

create table employee(
	emp_id char(3) 	PRIMARY KEY,
    e_fname varchar(15),
    e_lname varchar(15),
    e_mnum bigint,
    e_adrs varchar(40)	);
select * from employee;

create table products(
	pro_name varchar(20),
    pro_id char(10)  PRIMARY KEY,
    pro_price int,
    pro_stk  int);
select * from products;
drop table products;

create database shopping_ms;
use shopping_ms;
show tables;